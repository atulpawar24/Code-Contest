package com.app;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author Atul
 *
 */
@ApplicationPath("/app")
public class Demo extends Application {

}
